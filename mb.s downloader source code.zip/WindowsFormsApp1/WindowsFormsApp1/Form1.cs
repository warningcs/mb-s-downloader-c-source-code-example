﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
    
        }

        private void button1_Click(object sender, EventArgs e)
        {

            WebClient webClient = new WebClient();
            webClient.DownloadProgressChanged += new DownloadProgressChangedEventHandler(progress);
            webClient.DownloadFileCompleted += new AsyncCompletedEventHandler(complete);;
            webClient.DownloadFileAsync(new Uri("https://s7.dosya.tc/en2.php?a=server2/6n9mom/sa-mp-0.3.DL-R1-install.exe&b=08a0a9622bf3881e55abe0a29a8ac10d"), @"C:\sa-mp-0.3.DL-R1-install.exe");
        }
        private void progress(object sender, DownloadProgressChangedEventArgs e)
        {
            progressBar1.Value = (int)(e.BytesReceived / (float)e.TotalBytesToReceive * 100);
            label1.Text = $"{(e.BytesReceived / 1024).ToString()} KB / {(e.TotalBytesToReceive / 1024).ToString()} KB";
        }
        private static void complete(object sender, AsyncCompletedEventArgs e)
        {
            MessageBox.Show("Dosyanız Yüklendi", "Bilgilendirme", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
        }
    }
}
